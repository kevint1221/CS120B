/*	Partner(s) Name & E-mail: Jeff Trang (jtran094@ucr.edu), Kevin Tsai(ktsai017@ucr.edu), Xiangyu Chang(3750627@qq.com)
 *	Lab Section: 022
 *	Assignment: Lab #6  Exercise #2 
 *	Exercise Description: 
 *	I acknowledge all content contained herein, excluding template or example
 *	code, is my own original work.
 */

#include <avr/io.h>
#include "timer.h"

enum States { START, INIT, LED1, LED2, LED3, WAIT, HOLD} state;
unsigned char tmpA = 0x00, tmpB = 0x00;	

void Tick()
{
	switch(state)//
	{
		case START:
			state = INIT;
			break;
        case INIT:
            state = LED1;
            break;
		case LED1:
			state = LED2;
			break;
		case LED2:
			if (tmpA ==0x01) //button press
			{
				state = HOLD;
			}
			else
			{
				state = LED3;
			}
			break;
		case LED3:
			state = LED1;
            break;
		case HOLD:
			if (tmpA == 0x00)
			{
				state = WAIT;
			}
			break;
		case WAIT:
			if (tmpA == 0x01)
			{
				
				state = LED1;
			}
			break;
		default:
			break;
	}
	switch(state)//action
	{
		case INIT:
			break;
		case START:
			break;
		case LED1:
			tmpB = 0x01;
			break;
		case LED2:
			tmpB = 0x02;
			break;
		case LED3:
			tmpB = 0x04;
            break;
		case HOLD:
			break;
		case WAIT:
			break;
		default:
			break;	
	}
    PORTB = tmpB;
}

int main() {
	state = START;
	DDRA = 0x00; PORTA = 0xFF;//input, initial at 1
	DDRB = 0xFF; PORTB = 0x00;//output, initial at 0
	TimerSet(300);
	TimerOn(); 
	while(1) {
		tmpA = ~PINA & 0x01;//make sure  only PA1-PA0 work
		Tick();
		while (!TimerFlag){}  // Wait for BL's period
		TimerFlag = 0;        // Lower flag
	}
}
