/*	Partner(s) Name & E-mail: Jeff Trang (jtran094@ucr.edu), Kevin Tsai(ktsai017@ucr.edu), Xiangyu Chang(3750627@qq.com)
 *	Lab Section: 022
 *	Assignment: Lab #5  Exercise #2 
 *	Exercise Description: increment(PA0) PB up to 9 and decrement(PA1) PB down to 0, pressing both resets PB
 *	
 *	I acknowledge all content contained herein, excluding template or example
 *	code, is my own original work.
 */

#include <avr/io.h>
#include <stdio.h>

enum States { START, INIT, ADD, SUB, STOP, RESET, HOLD, RELEASE } state;
unsigned char tmpA = 0x00, tmpB = 0x00;
unsigned int count;
void Tick() {
    switch(state) { // Transitions
        case START:
            state = INIT;
            break;
        case INIT:
            if (tmpA == 0x01) { // add 1
                state = ADD;
            }
            else if (tmpA == 0x02) { // subtract 1
                state = SUB;
            }
            else if (tmpA == 0x03) { // reset
                state = RESET;
            }
            break;
        case ADD:
            if (tmpA == 0x02) { // subtract 1
                state = SUB;
            }
            else if (tmpB == 0x09) { // if B=9
                state = STOP;
            }
            else if (tmpA == 0x03) { // reset
                state = RESET;
            }
			else if ( tmpA == 0x01)
			{
				state = HOLD;
			}
            break;
        case SUB:
            if (tmpA == 0x01) { // add 1
                state = ADD;
            }
            else if (tmpB == 0x00) { // if B=0
                state = STOP;
            }
            else if (tmpA == 0x03) { // reset
                state = RESET;
            }
			else if (tmpA ==0x02)
			{
				state = HOLD;
			}
            break;
        case STOP:
			if (tmpA == 0x01 && tmpB != 0x09)
			{
				state = ADD;
			}
            if (tmpA == 0x02 && tmpB != 0x00) { // subtract 1
                state = SUB;
            }
            else if (tmpA == 0x03) { // reset
                state = RESET;
            }
            break;
		case HOLD:
			if (tmpA == 0x00)
			{
				state = RELEASE;
			}
			if (tmpA == 0x03)
			{
				state = RESET;
			}
			break;
		case RELEASE:
            if (tmpA == 0x01) { // add 1
	            state = ADD;
            }
            else if (tmpA == 0x02) { // subtract 1
	            state = SUB;
            }
            else if (tmpA == 0x03) { // reset
	            state = RESET;
            }
            break;			
        case RESET:
            if (tmpA == 0x01) { // add 1
                state = ADD;
            }
            break;
        default:
            break;
    }
    switch(state) { // State actions
        case INIT:
            tmpB = 0x00; //initial at 0
            PORTB = tmpB;
            break;
        case ADD:
            tmpB = tmpB + 0x01;
            PORTB = tmpB;
            break;
        case SUB:
            if (tmpB == 0x00) {
                break;     
            }         
            tmpB = tmpB - 0x01;
            PORTB = tmpB;   
            break;
        case STOP:
            break;
		case HOLD:
			break;
		case RELEASE:
			break;
        case RESET:
            tmpB = 0x00;
            PORTB = tmpB;
            break;
        default:
            break;
    }
}

int main() {
    state = START;
    DDRA = 0x00; PORTA = 0xFF;//input, initial at 1
    DDRB = 0xFF; PORTB = 0x00;//output, initial at 0
    while(1) {
        tmpA = ~PINA & 0x03;//make sure  only PA1-PA0 work
        Tick();
    }
}









