
/*	Partner(s) Name & E-mail: Jeff Trang (jtran094@ucr.edu), Kevin Tsai(ktsai017@ucr.edu), Xiangyu Chang(3750627@qq.com)
 *	Lab Section: 022
 *	Assignment: Lab #5  Exercise #3 
 *	Exercise Description: festive lights display with 6 LEDs,shift the sequence after the button connected to tmpA is pressed and released.
 *	
 *	I acknowledge all content contained herein, excluding template or example
 *	code, is my own original work.
 */

#include <avr/io.h>
#include <stdio.h>

unsigned char tmpA = 0x00;
unsigned char k=0;
unsigned char D;
enum States { Init, WaitRise, WaitFall } State;

Tick() {
   switch(State) { // Transitions
      case Init: 
         if (1) {
            State = WaitRise;
         }
         break;
      case WaitRise: 
         if (!tmpA) {
            State = WaitRise;
         }
         else if (tmpA) {
            State = WaitFall;
            D=0xFF<<k;
		PORTB = D;
            if(D==0) k=0;

            k=k+1;
         }
         break;
      case WaitFall: 
         if (!tmpA) {
            State = WaitRise;
         }
         else if (tmpA) {
            State = WaitFall;
         }
         break;
      default:
         State = Init;
   } // Transitions

   switch(State) { // State actions
      case Init:
         D=0xFF;
         break;
      case WaitRise:
         break;
      case WaitFall:
         break;
      default: // ADD default behaviour below
      break;
   } // State actions

}

int main() {

   State = Init; // Initial state
   D = 0; // Init outputs
    DDRA = 0x00; PORTA = 0xFF;
    DDRB = 0xFF; PORTB = 0x00;

   while(1) {
      tmpA = PINA & 0x01;
      Tick();
   } // while (1)
} // Main
