/*	Partner(s) Name & E-mail: Jeff Trang (jtran094@ucr.edu), Kevin Tsai(ktsai017@ucr.edu), Xiangyu Chang(3750627@qq.com)
 *	Lab Section: 022
 *	Assignment: Lab #5  Exercise #1 
 *	Exercise Description: set light level (PC) based on fuel level (PA)
 *	
 *	I acknowledge all content contained herein, excluding template or example
 *	code, is my own original work.
 */

#include <avr/io.h>

enum states {init, empty, led1, led2, led3, led4, led5, led6} state;

unsigned char tmpA = 0x00; // intermediate variable used for port updates
unsigned char ledB = 0xFF;
unsigned char tmpB = 0x00;


void Tick() 
{
	switch(state) //transition
	{
		case init:
			state = empty;
			break;
		case empty:
			if (tmpA > 0x00) //if fuel is 1-2
			{
				state = led1; //now in level 1 fuel state
			}
			break;
		case led1:
			if (tmpA > 0x02) //if fuel is 3-4
			{
				
				state = led2;
			}
			else if (tmpA < 0x01) // go back to empty
			{
				state = empty;
			}
			break;
		case led2:
			if (tmpA > 0x04)//if fuel is 5-6
			{
				state = led3;
			}
				else if (tmpA < 0x03) // go back to empty
			{
				state = led1;
			}
			break;
		case led3:
			if (tmpA > 0x06)//if fuel is 7-9
			{
				state = led4;
			}
			else if (tmpA < 0x05) // go back to empty
			{
				state = led2;
			}
			break;
		case led4: //if fuel is 10-12
			if(tmpA > 0x09)
			{
				state = led5;
			}
			else if (tmpA < 0x07) // go back to empty
			{
				state = led2;
			}			
			break;
		case led5://if fuel is 13-15
			if(tmpA > 0x0C)
			{
				state = led6;
			}
			else if (tmpA < 0x0A) // go back to empty
			{
				state = led2;
			}
			break;
		case led6:
			if (tmpA < 0x0D) // go back to empty
			{
				state = led2;
			}
			break;
	}
	
	switch(state) //action
	{
		case init:
			break;
		case empty: //PB6
			tmpB = 0x40;
			break;
		case led1: //PB6-PB5
			tmpB = 0x60;
			break;
		case led2://PB6- PB4
			tmpB = 0x70;
			break;
		case led3://PB5-PB3
			tmpB = 0x38;
			break;
		case led4: // PB5-PB2
			tmpB = 0x3C;
			break;
		case led5: //PB5-PB1
			tmpB = 0x3E;
			break;
		case led6: //PB5- PB0
			tmpB = 0x3F;
			break;
			
			
	}	
	PORTB = tmpB;
	tmpB = 0x00; //reset
}

int main(void)
{
	DDRA = 0x00; PORTA = 0xFF;//A as input, initial to 1
	DDRB = 0xFF; PORTB = 0x00;//B as output, initial to 0s

	state = init;
	while(1)
	{
		tmpA = ~PINA;
		Tick();
	}
}

