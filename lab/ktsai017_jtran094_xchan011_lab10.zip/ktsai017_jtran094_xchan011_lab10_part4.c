/*	Partner(s) Name & E-mail: Jeff Trang (jtran094@ucr.edu), Kevin Tsai(ktsai017@ucr.edu), Xiangyu Chang(3750627@qq.com)
 *	Lab Section: 022
 *	Assignment: Lab #10  Exercise #4
 *	Exercise Description: output blindlight threelight and speaker buzzer with button, ps: B0-B2 is threeLED, B3 is buzzer, B4 is flashLED
 *	I acknowledge all content contained herein, excluding template or example
 *	code, is my own original work.
 */

#include <avr/io.h>
//#include <avr/interrupt.h>
#include "timer.h"


// 0.954 hz is lowest frequency possible with this function,
// based on settings in PWM_on()
// Passing in 0 as the frequency will stop the speaker from generating sound
void set_PWM(double frequency) {
	static double current_frequency; // Keeps track of the currently set frequency
	// Will only update the registers when the frequency changes, otherwise allows
	// music to play uninterrupted.
	if (frequency != current_frequency) {
		if (!frequency) { TCCR0B &= 0x08; } //stops timer/counter
		else { TCCR0B |= 0x03; } // resumes/continues timer/counter
		
		// prevents OCR3A from overflowing, using prescaler 64
		// 0.954 is smallest frequency that will not result in overflow
		if (frequency < 0.954) { OCR0A = 0xFFFF; }
		
		// prevents OCR0A from underflowing, using prescaler 64					// 31250 is largest frequency that will not result in underflow
		else if (frequency > 31250) { OCR0A = 0x0000; }
		
		// set OCR3A based on desired frequency
		else { OCR0A = (short)(8000000 / (128 * frequency)) - 1; }

		TCNT0 = 0; // resets counter
		current_frequency = frequency; // Updates the current frequency
	}
}

void PWM_on() {
	TCCR0A = (1 << COM0A0) |  (1 << WGM00);//need second line to make it work
	// COM3A0: Toggle PB3 on compare match between counter and OCR0A
	TCCR0B = (1 << WGM02) | (1 << CS01) | (1 << CS00);
	// WGM02: When counter (TCNT0) matches OCR0A, reset counter
	// CS01 & CS30: Set a prescaler of 64
	set_PWM(0);
}

void PWM_off() {
	TCCR0A = 0x00;
	TCCR0B = 0x00;
}


unsigned char tmpA; //input for the button 
double adjustment[2] = {0.00, 261.62}; // first value set frequency to 0, second value is the frequency C4 at initial
double frequency= 0.00;  //initial at 0
unsigned char tmpB = 0x00, tmpC = 0x00;

enum three_States {START, LEDOne, LEDTwo, LEDThree} three_state;
enum blink_States {b_START, b_OFF, b_BLINK} blink_state;
enum speaker_states {speaker_start, speaker_off, speaker_on} speaker_state;
enum adjust_states {adjust_start, high, low, hold} adjust_state;
enum combine_States {c_start, c_exe} combine_state;



void Tick_three() {
    switch(three_state) {
        case START:
            three_state = LEDOne;
            break;
        case LEDOne:
            three_state = LEDTwo;
            break;
        case LEDTwo:
            three_state = LEDThree;
            break;
        case LEDThree:
            three_state = LEDOne;
            break;
        default:
            break;
    }
    switch(three_state) {
        case START:
            break;
        case LEDOne:
            tmpB = 0x01;
            break;
        case LEDTwo:
            tmpB = 0x02;
            break;
        case LEDThree:
            tmpB = 0x04;
            break;
        default:
            break;
    }
}

void Tick_blink() {
    switch(blink_state) {
        case b_START:
            blink_state = b_OFF;
            break;
        case b_OFF:
            blink_state = b_BLINK;
            break;
        case b_BLINK:
            blink_state = b_OFF;
            break;
        default:
            break;
    }
    switch(blink_state) {
        case b_START:
            break;
        case b_OFF:
            tmpC = 0x00;
            break;
        case b_BLINK:
            tmpC = 0x10;
            break;
        default:
            break;
    }
}

void Tick_speaker()
{
	switch(speaker_state) //transition
	{
		case speaker_start:
			speaker_state = speaker_on; //was set to off
			break;
		case speaker_off:
			if(tmpA == 0x01)
			{
				speaker_state = speaker_on;
			}
			break;
		case speaker_on:
			if(tmpA == 0x00)
			{
				speaker_state = speaker_off;
			} 
			break;
		default:
			break;
	}
	switch(speaker_state) //action
	{
		case speaker_start:
			break;
		case speaker_off:
			frequency = adjustment[0]; //set to 0
			break;	
		case speaker_on:
			frequency = adjustment[1]; //set to frequency
			break;
		default:
			break;
		
	}
}

void Tick_adjust() //adjust the frequency of buzzer
{
	switch(adjust_state) //transition
	{
		case adjust_start:
			if (tmpA == 0x02)
			{
				adjust_state = high;
			}
			else if (tmpA == 0x04)
			{
				adjust_state = low;
			}
			break;
		case high:
			adjust_state = hold;
			break;
		case low:
			adjust_state = hold;
			break;
		case hold:
			if(tmpA == 0x00)
			{
				adjust_state = adjust_start;
			}
			break;
		default:
			break;
	}
	switch(adjust_state) //action
	{
		case adjust_start:
			break;
		case high:
			adjustment[1] = adjustment[1] + 10.00; //increase the frequency 
			break;
		case low:
			adjustment[1] = adjustment[1] - 10.00;//lower the frequency
			break;
		case hold:
			break;
		default:
			break;
	}
	
}
void Tick_combine() {
    switch(combine_state) {
        case c_start:
            combine_state = c_exe;
            break;
        case c_exe:
            break;
        default:
            break;
    }
    switch(combine_state) {
        case c_start:
            break;
        case c_exe:
            PORTB = tmpB | tmpC;
			set_PWM(frequency);
            break;
        default:
            break;        
    }
}

int main(void) {
    /* Replace with your application code */
	DDRA = 0x00; PORTA = 0xFF;//input, initial at 1

    DDRB = 0xFF; PORTB = 0x00;
    unsigned long three_elapsed = 0, blink_elapsed = 0, speaker_elapsed = 0, adjust_elapsed = 0;
	
    const unsigned long timer_period = 100; // GCD of 300 & 1000
	PWM_on();
    three_state = START;
    blink_state = b_START;
	speaker_state = speaker_start;
	adjust_state = adjust_start;
    combine_state = c_start;

    TimerSet(1);
    TimerOn();
    while (1) {
		tmpA = ~PINA ;

        if (three_elapsed >= 30000) { //300ms  //1ms for set timer, 100 for period of time
            Tick_three();
            Tick_combine();
            three_elapsed = 0;    
        }
        if (blink_elapsed >= 100000) { //1000ms  //1ms for timer, 100 for period of time
            Tick_blink();
            Tick_combine();
            blink_elapsed = 0;
        }
		if (adjust_elapsed >= 5000 ) // 50ms
		{
			Tick_adjust();
			Tick_combine();
			adjust_elapsed = 0;
		}
		if (speaker_elapsed >= 100) //1ms 
		{
			Tick_speaker();
			Tick_combine();
			speaker_elapsed = 0;	
		}
	
        while (!TimerFlag) {}
        TimerFlag = 0;    
        three_elapsed += timer_period;
        blink_elapsed += timer_period;
		speaker_elapsed += timer_period;
		adjust_elapsed += timer_period;
    }
}

