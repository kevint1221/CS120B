/*	Partner(s) Name & E-mail: Jeff Trang (jtran094@ucr.edu), Kevin Tsai(ktsai017@ucr.edu), Xiangyu Chang(3750627@qq.com)
 *	Lab Section: 022
 *	Assignment: Lab #10  Exercise #2 
 *	Exercise Description: output three LEDs individually every 300 milliseconds & output one LEDs blinking on/off every second 
 *	
 *	I acknowledge all content contained herein, excluding template or example
 *	code, is my own original work.
 */

#include <avr/io.h>
#include <avr/interrupt.h>
#include "timer.h"

unsigned char tmpB = 0x00, tmpC = 0x00;

enum three_States {START, LEDOne, LEDTwo, LEDThree} three_state;
enum blink_States {b_START, b_OFF, b_BLINK} blink_state;
enum combine_States {c_start, c_exe} combine_state;

void Tick_three() {
    switch(three_state) {
        case START:
            three_state = LEDOne;
            break;
        case LEDOne:
            three_state = LEDTwo;
            break;
        case LEDTwo:
            three_state = LEDThree;
            break;
        case LEDThree:
            three_state = LEDOne;
            break;
        default:
            break;
    }
    switch(three_state) {
        case START:
            break;
        case LEDOne:
            tmpB = 0x01;
            break;
        case LEDTwo:
            tmpB = 0x02;
            break;
        case LEDThree:
            tmpB = 0x04;
            break;
        default:
            break;
    }
}

void Tick_blink() {
    switch(blink_state) {
        case b_START:
            blink_state = b_OFF;
            break;
        case b_OFF:
            blink_state = b_BLINK;
            break;
        case b_BLINK:
            blink_state = b_OFF;
            break;
        default:
            break;
    }
    switch(blink_state) {
        case b_START:
            break;
        case b_OFF:
            tmpC = 0x00;
            break;
        case b_BLINK:
            tmpC = 0x08;
            break;
        default:
            break;
    }
}

void Tick_combine() {
    switch(combine_state) {
        case c_start:
            combine_state = c_exe;
            break;
        case c_exe:
            break;
        default:
            break;
    }
    switch(combine_state) {
        case c_start:
            break;
        case c_exe:
            PORTB = tmpB | tmpC;
            break;
        default:
            break;        
    }
}

int main(void) {
    /* Replace with your application code */
    DDRB = 0xFF; PORTB = 0x00;
    unsigned long three_elapsed = 0, blink_elapsed = 0;
    const unsigned long timer_period = 100; // GCD of 300 & 1000
    three_state = START;
    blink_state = b_START;
    combine_state = c_start;
    TimerSet(100);
    TimerOn();
    while (1) {
        if (three_elapsed >= 300) {
            Tick_three();
            Tick_combine();
            three_elapsed = 0;    
        }
        if (blink_elapsed >= 1000) {
            Tick_blink();
            Tick_combine();
            blink_elapsed = 0;
        }
        while (!TimerFlag) {}
        TimerFlag = 0;    
        three_elapsed += timer_period;
        blink_elapsed += timer_period;
    }
}

