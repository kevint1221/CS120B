/*	Partner(s) Name & E-mail: Jeff Trang (jtran094@ucr.edu), Kevin Tsai(ktsai017@ucr.edu), Xiangyu Chang(3750627@qq.com)
 *	Lab Section: 022
 *	Assignment: Lab #10  Exercise #5
 *	Exercise Description: increment/decrement binary based on button press, if hold the button, increment/decrement
 *  happen with different speed 
 *	I acknowledge all content contained herein, excluding template or example
 *	code, is my own original work.
 */

#include <avr/io.h>
//#include <avr/interrupt.h>
#include "timer.h"

unsigned char tmpA; //input for the button 
unsigned char tmpB = 0x00; //output for LED
unsigned long counter = 0; //count how long button press hold
unsigned char trigger = 0; //trigger increment or decrement if button hold for certain time
enum adjust_states {adjust_start, add, minus, hold, reset} adjust_state;
enum trigger_states {trigger_start, trigger_press, trigger_1sec, trigger_p4sec} trigger_state;
enum combine_States {combine_start, combine_exec} combine_state;


void Tick_adjust() //also execute state
{
	switch(adjust_state)//transition
	{
		case adjust_start:
			if(tmpA == 0x01)
			{
				adjust_state = add;
			}
			else if (tmpA ==0x02)
			{
				adjust_state = minus;
			}
			else if (tmpA ==0x03)
			{
				adjust_state = reset;
			}
			break;
		case add:
			adjust_state = hold;
			break;
		case minus:
			adjust_state = hold;
			break;
		case hold:
			if (tmpA == 0x00)
			{
				adjust_state = adjust_start;
				
			}
			else if (tmpA == 0x01 && trigger == 1)
			{
				adjust_state = add;
				trigger = 0; //reset value
			}
			else if (tmpA == 0x02 && trigger == 1)
			{
				adjust_state = minus;
				trigger = 0;  //reset value
			}
			else if (tmpA == 0x03)
			{
				adjust_state = reset;
			}
			break;
		case reset:
			if(tmpA ==0x00)
			{
				adjust_state = adjust_start;
			}
			break;
		default:
			break;
	}
	
	switch(adjust_state)//action
	{
		case adjust_start:
			counter = 0;
			break;
		case add:
			if (tmpB < 0x09)
			{
				tmpB += 0x01;	
			}
			break;
		case minus:
			if (tmpB >0)
			{
				tmpB -= 0x01;
			}
			break;
		case hold:
			counter +=1;
			break;
		case reset:
			tmpB = 0x00;
			counter = 0;
			break;
		default:
			break;	
	}
}
void Tick_combine()
{
	switch(combine_state)//transition
	{
		case combine_start:
			combine_state = combine_exec;
			break;
		case combine_exec:
			break;
		default:
			break;
	}
	switch(combine_state)//action
	{
		case combine_start:
			break;
		case combine_exec:
			PORTB = tmpB;
			break;
		default:
			break;
	}
	
}
void Tick_trigger()
{
	switch(trigger_state) //transition 
	{
		case trigger_start:
			trigger_state = trigger_press;
			break;
		case trigger_press:
		
			if (counter >= 10) //if press more than 0.5 sec enter 1 second state
			{
				trigger_state = trigger_1sec;
			}
			break;
		case trigger_1sec:
			if (counter >= 60) //continue holding for at least 3sec
			{
				trigger_state = trigger_p4sec;

			}
			else if (counter ==0)
			{
				trigger_state = trigger_press;
			}
			break;
		case trigger_p4sec:
			if (counter == 0)
			{
				trigger_state = trigger_press;
			}
			break;
		default:
			break;
	}
	switch(trigger_state) //action
	{
		case trigger_start:
			break;
		case trigger_press:
			break;
		case trigger_1sec:
			if (counter%20 ==0) //triggered every 1 sec  
			{
				trigger = 1;
			}
			break;
		case trigger_p4sec:
			if (counter%8) //triggered every 400ms 
			{
				trigger = 1;
			}
			break;
		default:
			break;
	}
}


int main(void)
{
	DDRA = 0x00; PORTA = 0xFF;//input, initial at 1
	DDRB = 0xFF; PORTB = 0x00; //output
	unsigned long adjust_elapsed = 0, trigger_elapsed = 0;
	const unsigned long timer_period = 1; // debounce time gdb of 50 and 1
	adjust_state = adjust_start;
	trigger_state = trigger_start;
	combine_state = combine_start;
	
	TimerSet(1);
	TimerOn();
	
	while(1)
	{
		tmpA = ~PINA; 
		if (adjust_elapsed >= 50)
		{ 
			Tick_adjust();
			Tick_combine();
			adjust_elapsed = 0;
		}
		if (trigger_elapsed >= 1)
		{
			Tick_trigger();
			Tick_combine();
			trigger_elapsed = 0;
		}
		while (!TimerFlag) {}
		TimerFlag = 0;
		adjust_elapsed += timer_period;
		trigger_elapsed += timer_period;
	}
	
	
	
	
	
}


