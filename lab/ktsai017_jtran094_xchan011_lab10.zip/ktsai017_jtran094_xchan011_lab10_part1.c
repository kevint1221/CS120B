/*
 * ktsai017_lab10.c
 *
 * Created: 2/12/2019 1:05:47 PM
 * Author : kai
 */ 

#include <avr/io.h>
#include "timer.h"


unsigned char tmpB;
unsigned char tmpC;
unsigned char tmpD;
enum three_led {tl_start, tl_led1, tl_led2, tl_led3} tl_state;

void tick_tl() //three led blind
{
	switch(tl_state)//transition
	{
		case tl_start:
			tl_state = tl_led1;
			break;
		case tl_led1:
			tl_state = tl_led2;
			break;
		case tl_led2:
			tl_state = tl_led3;
			break;
		case tl_led3:
			tl_state = tl_led1;
			break;
		default:
			break;
	}
	
	switch(tl_state)//action
	{
		case tl_start:
			break;
		case tl_led1:
		//	tmpB = tmpB | 0x01 ;
			tmpB = 0x01;
			break;
		case tl_led2:
			tmpB = 0x02;
			break;
		case tl_led3:
			tmpB = 0x04;
			break;
		default:
			break;
	}
	
}	

enum bl_led {bl_start, bl_off, bl_on} bl_state;
	
void tick_bl()
{
	switch(bl_state) //transition
	{
		case bl_start:
			bl_state = bl_off;
			break;
		case bl_off:
			bl_state = bl_on;
			break;
		case bl_on:
			bl_state = bl_off;
			break;
		default:
			break;
	}
	switch(bl_state)
	{
		case bl_start:
			break;
		case bl_off:
			tmpC = 0x00;
			break;
		case bl_on:
			tmpC = 0x08;
			break;
		default:
			break;
	}
}

enum combine_state {start, on, off} cb_state;
	
	

void tick() //
{
		switch(cb_state) //transition
		{
			case start:
			cb_state = off;
			break;
			case off:
			cb_state = on;
			break;
			case on:
			cb_state = off;
			break;
			default:
			break;
		}
		switch(cb_state)
		{
			case start:
			break;
			case off:
			tmpD = tmpB + tmpC;
			break;
			case on:
			tmpD = tmpB + tmpC;
			break;
			default:
			break;
		}
		PORTB = tmpD;
}



int main(void)
{
	
	DDRB = 0xFF; PORTB = 0x00;//output, initial at 0
	
	TimerSet(1000);
	TimerOn();
	tl_state = tl_start;
	bl_state = bl_start;
	cb_state = start;
	tmpB = 0x00; //initial
    /* Replace with your application code */
    while (1) 
    {
		tick_tl();
		tick_bl();
		tick();
		while (!TimerFlag){}  // Wait for BL's period
		TimerFlag = 0;        // Lower flag
    }

}

