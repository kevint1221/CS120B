/*	Partner(s) Name & E-mail: Jeff Trang (jtran094@ucr.edu), Xiangyu Chang(3750627@qq.com)
 *	Lab Section: 022
 *	Assignment: Lab #3  Exercise #5 
 *	Exercise Description: enable airbag(PB1) if weight exceeds 70 lbs, disable airbag(PB2) if weight is between 5-70 lbs
 *	
 *	I acknowledge all content contained herein, excluding template or example
 *	code, is my own original work.
 */

#include <avr/io.h>

int main(void)
{
    DDRD = 0x00; PORTD = 0xFF; // Configure port D's 8 pins as inputs
    DDRB = 0xFE; PORTB = 0x00; // Configure port B's first pin as input
     
    // initialize to 0s
    unsigned short weight = 0x0000; // need 9 bits   //set to 0 is fine
    unsigned char tmpD = 0x00, tmpB = 0x00;
    
    while (1)
    {
        tmpD = PIND;
        tmpB = PINB & 0x01; // only first bit of B
        
        weight = (tmpD << 1) + tmpB; // left-shift PD + PB0 to obtain total weight
        
        if (weight >= 70) { // enable airbag (PB1)
            tmpB = 0x02;
        }
        else if (weight > 5 && weight < 70) { // disable airbag & enable airbag icon (PB2) 
            tmpB = 0x04;
        }
        else { // no passenger
            tmpB = 0x00;
        }
        
        PORTB = tmpB;
    }
}
