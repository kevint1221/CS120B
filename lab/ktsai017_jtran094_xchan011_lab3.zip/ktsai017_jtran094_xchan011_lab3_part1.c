
/*	Partner(s) Name & E-mail: Jeff Trang (jtran094@ucr.edu), Xiangyu Chang(3750627@qq.com)
 *	Lab Section: 022
 *	Assignment: Lab #3  Exercise #1 
 *	Exercise Description: output number of 1-bits from ports A & B to C
 *	
 *	I acknowledge all content contained herein, excluding template or example
 *	code, is my own original work.
 */


#include <avr/io.h>

unsigned char GetBit(unsigned char x, unsigned char k) {
	return ((x & (0x01 << k)) != 0);
}

int main(void) {
	DDRA = 0x00; PORTA = 0xFF; // Configure port A's 8 pins as inputs
	DDRB = 0x00; PORTB = 0xFF; // Configure port B's 8 pins as inputs
	DDRC = 0xFF; PORTC = 0x00; // Configure port C's 8 pins as outputs, initialize to 0s
	unsigned char tmpA = 0x00, tmpB = 0x00, tmpC = 0x00; // Temporary variable to hold the values
	
	while(1) {
		// 1) Read input
		tmpA = PINA; // PA# assigned to each bit
		tmpB = PINB;
		// 2) Perform computation
		for (int i = 0; i < 8; i++) {
			if (GetBit(tmpA, i) == 1) { // if A[i] = 1, add to counter
				tmpC = tmpC + 0x01;
			}
			if (GetBit(tmpB, i) == 1){ // if B[i] = 1, add to counter
				tmpC = tmpC + 0x01;
			}
		}
		// 3) Write output
		PORTC = tmpC;
		tmpC = 0x00; // reset counter
	}
	return 0;
}
