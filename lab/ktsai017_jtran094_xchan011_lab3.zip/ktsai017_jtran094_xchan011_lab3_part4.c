/*	Partner(s) Name & E-mail: Jeff Trang (jtran094@ucr.edu), Kevin Tsai(ktsai017@ucr.edu), Xiangyu Chang(3750627@qq.com)
 *	Lab Section: 022
 *	Assignment: Lab #3  Exercise #4 
 *	Exercise Description: set A's upper nibble to B's lower nibble & A's lower nibble to C's upper nibble
 *	
 *	I acknowledge all content contained herein, excluding template or example
 *	code, is my own original work.
 */

#include <avr/io.h>

int main(void)
{
    DDRA = 0x00; PORTA = 0xFF; // Configure port A's 8 pins as inputs
    DDRB = 0xFF; PORTB = 0x00; // Configure port B & C's 8 pins as outputs,
    DDRC = 0xFF; PORTC = 0x00; 
    // initialize to 0s
    unsigned char tmpAtoB = 0x00, tmpAtoC = 0x00, tmpB = 0x00, tmpC = 0x00;
    
    while (1)
    {
        tmpAtoB = PINA & 0xF0; // upper nibble of A
        tmpAtoC = PINA & 0x0F; // lower nibble of A
        
        tmpB = tmpAtoB >> 4;
        tmpC = tmpAtoC << 4;
        
        PORTB = tmpB;
        PORTC = tmpC;
    }
}


