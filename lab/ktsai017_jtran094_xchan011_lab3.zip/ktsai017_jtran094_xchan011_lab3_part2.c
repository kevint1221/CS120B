/*	Partner(s) Name & E-mail: Jeff Trang (jtran094@ucr.edu), Kevin Tsai(ktsai017@ucr.edu), Xiangyu Chang(3750627@qq.com)
 *	Lab Section: 022
 *	Assignment: Lab #3  Exercise #2 
 *	Exercise Description: set light level (PC) based on fuel level (PA)
 *	
 *	I acknowledge all content contained herein, excluding template or example
 *	code, is my own original work.
 */

#include <avr/io.h>

unsigned char SetBit(unsigned char x, unsigned char k, unsigned char b) {
	return (b ? x | (0x01 << k) : x & ~(0x01 << k));
}
unsigned char GetBit(unsigned char x, unsigned char k) {
	return ((x & (0x01 << k)) != 0);
}

int main(void)
{
	DDRA = 0x00; PORTA = 0xFF; // Configure port A's 8 pins as inputs
	DDRC = 0xFF; PORTC = 0x00; // Configure port C's 8 pins as outputs,
	// initialize to 0s
	unsigned char tmpA = 0x00; // intermediate variable used for port updates
	unsigned char ledC = 0xFF;
	unsigned char tmpC = 0x00;
    /* Replace with your application code */
    while (1) 
    {
		tmpA = PINA;
        			 
		if (tmpA <= 0x0F && tmpA >= 0x0D) // 13-15 --> PC5-PC0 
		{
			ledC = 0xFF;
		}
		if(tmpA <= 0x0C && tmpA >= 0x0A) // 10-12 --> PC5-PC1
		{
			ledC = 0xFF << 1;
		}
		if (tmpA <= 0x09 && tmpA >= 0x07) // 7-9 --> PC5-PC2
		{
			ledC = 0xFF << 2;	
		}
		if (tmpA <= 0x06 && tmpA >= 0x05) // 5-6 --> PC5-PC3
		{
			ledC = 0xFF << 3;
		}
		if (tmpA <= 0x04 && tmpA >= 0x03) // 3-4 --> PC5-PC4
		{
			ledC = 0xFF << 4;
		}
		if (tmpA <= 0x02 && tmpA >= 0x01) // 1-2 --> PC5
        	{
           		ledC = 0xFF << 5;
       	}
		if (tmpA == 0x00) { // 0 --> all off
           		ledC = 0xFF << 6;
        	}
		
		tmpC = ledC & 0x3F;
		
		if (tmpA <= 0x04) // if PA <= 4, set PC6
        	{
           		tmpC = tmpC + 0x40;
        	}

		PORTC = tmpC;
    }
}












