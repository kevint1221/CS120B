/*	Partner(s) Name & E-mail:
 *	Lab Section: 022
 *	Assignment: Lab # 1 Exercise # 3
 *  Exercise Description: see the output of overflow input

 *	I acknowledge all content contained herein, excluding template or example
 *	code, is my own original work.
 */
 
#include "RIMS.h"


unsigned char x;
void main() {
 while (1) {
 x = 257; // B = 4, overflow 5
 B = x;
 }
}