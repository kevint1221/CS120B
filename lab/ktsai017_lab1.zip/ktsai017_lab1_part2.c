/*	Partner(s) Name & E-mail:
 *	Lab Section: 022
 *	Assignment: Lab # 1 Exercise # 2
 *  Exercise Description: assign value x to change output, and monitor it

 *	I acknowledge all content contained herein, excluding template or example
 *	code, is my own original work.
 */

#include "RIMS.h"


unsigned char x; //int work too 
                  // C language can't delcear 1 bit

void main() {
 while (1) {
 x = A;
 B = x;
 }
}
