/*	Partner(s) Name & E-mail:
 *	Lab Section: 022
 *	Assignment: Lab # 1 Exercise # 4
 *  Exercise Description: set all output to input

 *	I acknowledge all content contained herein, excluding template or example
 *	code, is my own original work.
 */

#include "RIMS.h"

unsigned char y;
void main()
{
   
   while (1) { 
      y = 'm\n';
      B = y;
      putc(y);
      putc('\n');
      }
}
