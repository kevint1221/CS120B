/*	Partner(s) Name & E-mail:
 *	Lab Section: 022
 *	Assignment: Lab # 1 Exercise # 1
 *  Exercise Description: set all output to input

 *	I acknowledge all content contained herein, excluding template or example
 *	code, is my own original work.
 */


#include "rims.h"


void main()
{
   while (1) { 
      
      B = A;
   }
}
