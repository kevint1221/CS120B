/*	Partner(s) Name & E-mail: Jeff Trang (jtran094@ucr.edu), Kevin Tsai(ktsai017@ucr.edu), Xiangyu Chang(3750627@qq.com)
 *	Lab Section: 022
 *	Assignment: Lab #7  Exercise #2 
 *	Exercise Description: 
 *	I acknowledge all content contained herein, excluding template or example
 *	code, is my own original work.
 */


#include <avr/io.h>
#include "timer.h"
#include "io.c"


enum States { START, INIT, LED1, LED2, LED3, WAIT, HOLD} state;
unsigned char tmpA = 0x00, tmpB = 0x00;
unsigned char total = 0x00; //total of add and subtraction
unsigned char count =0x00;
void Tick()
{
	switch(state)//
	{
		case START:
		state = INIT;
		break;
		case INIT:
		state = LED1;
		break;
		case LED1:
		state = LED2;
		break;
		case LED2:
		if (tmpA ==0x01) //button press
		{
			state = HOLD;
		}
		else
		{
			state = LED3;
		}
		break;
		case LED3:
		state = LED1;
		break;
		case HOLD:
		
		if (tmpA == 0x00)
		{
			state = WAIT;
			
		}
		break;
		case WAIT:
		
		if (total >=9)
		{
			if (count <3)
			{
				state = HOLD;
				count++;
			}
			else
			{
				LCD_ClearScreen();
				count = 0;
				total = 0x05;
				state = LED1;
				LCD_Cursor(1);
				LCD_WriteData(total +'0');
			}
		}
		else
		{
			
			state = LED1;
			
		}
		break;
		default:
		break;
	}
	switch(state)//action
	{
		case INIT:
		total = 0x05;
		LCD_Cursor(1);
		LCD_WriteData(total +'0');
		break;
		case START:
		break;
		case LED1:
	
		tmpB = 0x01;
		if (tmpA ==0x01)
		{
			if (total <=0)
			{
				//do nothing
			}
			else
			{
				total -=1;
				LCD_Cursor(1);
				LCD_WriteData(total +'0');
			}
			
		}
		break;
		case LED2:
		tmpB = 0x02;
		break;
		case LED3:
		tmpB = 0x04;
		if (tmpA ==0x01)
		{
			if (total <=0)
			{
				//do nothing
			}
			else
			{
				total -=1;
				LCD_Cursor(1);
				LCD_WriteData(total +'0');
			}
			
		}
		break;
		case HOLD:
		if (total >= 0x09)
		{
			LCD_DisplayString(1, "winner dinner");
		}
		else
		{
			total += 0x01;
			LCD_Cursor(1);
			LCD_WriteData(total +'0');
		}
		
		break;
		case WAIT:
		break;
		default:
		break;
	}
	PORTB = tmpB;
}

int main() {
	state = START;
	DDRA = 0x00; PORTA = 0xFF;//input, initial at 1
	DDRB = 0xFF; PORTB = 0x00;//output, initial at 0
	DDRC = 0xFF; PORTC = 0x00; // LCD data lines
	DDRD = 0xFF; PORTD = 0x00; // LCD control lines
	
	LCD_init();
	
	TimerSet(300);
	TimerOn();
	while(1) {
		tmpA = ~PINA & 0x01;//make sure  only PA1-PA0 work
		Tick();
		while (!TimerFlag){}  // Wait for BL's period
		TimerFlag = 0;        // Lower flag
	}
}



