/*	Partner(s) Name & E-mail: Jeff Trang (jtran094@ucr.edu), Kevin Tsai(ktsai017@ucr.edu), Xiangyu Chang(3750627@qq.com)
 *	Lab Section: 022
 *	Assignment: Lab #7  Exercise #1 
 *	Exercise Description: 
 *	I acknowledge all content contained herein, excluding template or example
 *	code, is my own original work.
 */

#include <avr/io.h>
#include "io.c"
#include "timer.h"



enum States {start, init, on, add, sub, addc, subc, reset} state;
unsigned char tmpA = 0x00; //use for input
unsigned char total = 0x00; //total of add and subtraction
unsigned char count = 0;//count the clock cycle

void Tick()
{
	switch(state)// transition
	{
		case start:
			state = init;
			break;
		case init:
			state = on;
			break;
		case on:
			if(tmpA == 0x03)
			{
				state = reset;
			}
			else if (tmpA == 0x01)
			{
				state = add;
				if(total >= 0x09)
				{
					//do nothing
				}
				else
				{
					total += 0x01;//+1
					LCD_Cursor(1);
					LCD_WriteData(total +'0');
				}
			}
			else if (tmpA ==0x02)
			{
				state = sub;
				if(total <= 0x00)
				{
					//do nothing
				}
				else
				{
					total -= 0x01; //-1
					LCD_Cursor(1);
					LCD_WriteData(total +'0');
				}
			
			}
			break;
		case add:
			if(tmpA == 0x03)
			{
				state = reset;
			}
		    else if (tmpA == 0x00)
			{
				state = on;
			}
			else if (tmpA == 0x01 && count <9 && total < 0x09 )
			{
				state = add;
			}
			else if (count > 9 && tmpA ==0x01)
			{
				state = addc;
			}
			break;
		case addc:
			state = add;
			break;
		case sub:
			if(tmpA == 0x03)
			{
				state = reset;
			}
			else if (tmpA == 0x00)
			{
				state = on;
			}
			else if (tmpA == 0x02 && count <9 && total > 0x00 )
			{
				state = sub;
			}
			else if (count > 9 && tmpA ==0x02)
			{
				state = subc;
			}
			break;
		case subc:
			state = sub;
			break;
		case reset:
			if (tmpA ==00)
			{
				state = init;
			}
			break;
		default:
			break;
		
	}
	switch (state) // action
	{
		case start:
			break;
		case init:
			total = 0x00;
			LCD_Cursor(1);
			LCD_WriteData(total +'0');
			break;
		case on:
			count = 0;
			break;
		case add:
			count += 1;
			break;
		case addc:
			if(total >=9)
			{
				
				//do nothing
			}
			else
			{
				total += 0x01;//+1
				LCD_Cursor(1);
				LCD_WriteData(total +'0');
				count = 0;
				
			}
			break;
		case sub:
			count += 1;
			break;
		case subc:
			if (total <= 0x00)
			{
				//do nothing
			}
			else
			{
				total -= 0x01;//-1
				LCD_Cursor(1);
				LCD_WriteData(total +'0');
				count = 0;	
			}
			break;
		case reset:
			break;
		default:
			break;
	}
	
}

int main(void)
{
	state = start;
	DDRC = 0xFF; PORTC = 0x00; // LCD data lines
	DDRD = 0xFF; PORTD = 0x00; // LCD control lines
	DDRA = 0x00; PORTA = 0xFF; //input, initial at 1
	
	// Initializes the LCD display
	LCD_init();
	// Starting at position 1 on the LCD screen, writes Hello World
	TimerSet(100); //100ms for a tick
	TimerOn();
	LCD_ClearScreen();
	while(1)
	{
		
		tmpA = ~PINA;
		Tick();
		while (!TimerFlag){}  // Wait for BL's period
		TimerFlag = 0;        // Lower flag
	}
}





