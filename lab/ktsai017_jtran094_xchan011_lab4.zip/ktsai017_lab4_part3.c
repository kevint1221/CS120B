/*	Partner(s) Name & E-mail: Jeff Trang (jtran094@ucr.edu), Kevin Tsai(ktsai017@ucr.edu), Xiangyu Chang(3750627@qq.com)
 *	Lab Section: 022
 *	Assignment: Lab #4  Exercise #3 
 *	Exercise Description: pressing '#'(PA2) then 'Y'(PA1) unlocks the door, pressing PA7 locks the door
 *	
 *	I acknowledge all content contained herein, excluding template or example
 *	code, is my own original work.
 */

#include <avr/io.h>
#include <stdio.h>

enum States { START, INIT, S_HASH, S_Y } state;
unsigned char tmpA = 0x00, tmpB = 0x00;
    
void Tick() {
    switch(state) { // Transitions
        case START:
            state = INIT;
            break;
        case INIT:
            if (tmpA == 0x04) { // press only '#'(PA2)
                state = S_HASH;
            }
            else { // never correct, reset to initial
                state = INIT;
            }
            break;
        case S_HASH:
            if (tmpA == 0x02) { // press only 'Y'(PA1)
                state = S_Y;
            }
            else if (tmpA & 0x04 || ~tmpA & 0x02 || tmpA & 0x01 || tmpA & 0x80) { // incorrect, reset to initial
                state = INIT;
            }
            break;
        case S_Y:
            if (tmpA & 0x80) { // press button inside(PA7)
                state = INIT;
            }
            break;
		default:
			break;
    }
    switch(state) { // State actions
        case INIT:
            tmpB = 0x00;
            PORTB = tmpB;
            break;
        case S_HASH:
            break;
        case S_Y:
            tmpB = 0x01;
            PORTB = tmpB;
            break;
		default:
			break;
    }
}

int main() {
    state = START;
    DDRA = 0x00; PORTA = 0xFF;
    DDRB = 0xFF; PORTB = 0x00;
    while(1) {
        tmpA = PINA & 0x87; // only receive input from pins A7, A2, A1, A0
        Tick();
    }
}



