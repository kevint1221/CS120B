/*	Partner(s) Name & E-mail: Jeff Trang (jtran094@ucr.edu), Kevin Tsai(ktsai017@ucr.edu), Xiangyu Chang(3750627@qq.com)
 *	Lab Section: 022
 *	Assignment: Lab #4  Exercise #1 
 *	Exercise Description: switch between PB0 & PB1 states whenever PA0 is pressed
 *	
 *	I acknowledge all content contained herein, excluding template or example
 *	code, is my own original work.
 */

#include <avr/io.h>
#include <stdio.h>

enum States { START, PBZERO, PBONE } state;
unsigned char tmpA = 0x00, tmpB = 0x00;
    
void Tick() {
    switch(state) { // Transitions
        case START:
            state = PBZERO;
            break;
        case PBZERO:
            if (tmpA == 0x01) { // if PA0
                state = PBONE;
            }
            else { // if !(PA0)
                state = PBZERO;
            }
            break;
        case PBONE:
            if (tmpA == 0x01) { // if PA0
                state = PBZERO;
            }
            else { // if !(PA0)
                state = PBONE;
            }
            break;
      	  default:
		{
			
			break;}

    }
    switch(state) { // State actions
	  case START:
		{
			break;
}

        case PBZERO:
            tmpB = 0x01;
            PORTB = tmpB;
            break;
        case PBONE:
            tmpB = 0x02;
            PORTB = tmpB;
            break;
	  default:
		{
			
			break;
}
    }
	
}

int main() {
    state = START;
    DDRA = 0x00; PORTA = 0xFF;
    DDRB = 0xFF; PORTB = 0x00;
    while(1) {
	  tmpA = PINA;
        Tick();
    }
}
