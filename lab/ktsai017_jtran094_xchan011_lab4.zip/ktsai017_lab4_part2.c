/*	Partner(s) Name & E-mail: Jeff Trang (jtran094@ucr.edu), Kevin Tsai(ktsai017@ucr.edu), Xiangyu Chang(3750627@qq.com)
 *	Lab Section: 022
 *	Assignment: Lab #4  Exercise #2 
 *	Exercise Description: increment(PA0) PC up to 9 and decrement(PA1) PC down to 0, pressing both resets PC
 *	
 *	I acknowledge all content contained herein, excluding template or example
 *	code, is my own original work.
 */

#include <avr/io.h>
#include <stdio.h>

enum States { START, INIT, ADD, SUB, STOP, RESET } state;
unsigned char tmpA = 0x00, tmpC = 0x00;
    
void Tick() {
    switch(state) { // Transitions
        case START:
            state = INIT;
            break;
        case INIT:
            if (tmpA == 0x01) { // add 1
                state = ADD;
            }
            else if (tmpA == 0x02) { // subtract 1
                state = SUB;
            }
            else if (tmpA == 0x03) { // reset
                state = RESET;
            }
            break;
        case ADD:
            if (tmpA == 0x02) { // subtract 1
                state = SUB;
            }
            if (tmpC == 0x09) { // if C=9
                state = STOP;
            }
            else if (tmpA == 0x03) { // reset
                state = RESET;
            }
            break;
        case SUB:
            if (tmpA == 0x01) { // add 1
                state = ADD;
            }
            else if (tmpC == 0x00) { // if C=0
                state = STOP;
            }
            else if (tmpA == 0x03) { // reset
                state = RESET;
            }
            break;
        case STOP:
            if (tmpA == 0x02) { // subtract 1
                state = SUB;
            }
            else if (tmpA == 0x03) { // reset
                state = RESET;
            }
            break;
        case RESET:
            if (tmpA == 0x01) { // add 1
                state = ADD;
            }
            break;
		default:
			break;
    }
    switch(state) { // State actions
        case INIT:
            tmpC = 0x07;
            PORTC = tmpC;
            break;
        case ADD:
            tmpC = tmpC + 0x01;
            PORTC = tmpC;
            break;
        case SUB:
			if ( tmpC == 0x00)
			{
				break;
			}
            tmpC = tmpC - 0x01;
            PORTC = tmpC;
            break;
        case STOP:
            break;
        case RESET:
            tmpC = 0x00;
            PORTC = tmpC;
            break;
		default:
			break;
    }
}

int main() {
    state = START;
    DDRA = 0x00; PORTA = 0xFF;
    DDRC = 0xFF; PORTC = 0x00;
    while(1) {
        tmpA = PINA;
        Tick();
    }
}


