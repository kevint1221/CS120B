/*	Partner(s) Name & E-mail: Jeff Trang (jtran094@ucr.edu), Kevin Tsai(ktsai017@ucr.edu), Xiangyu Chang(3750627@qq.com)
 *	Lab Section: 022
 *	Assignment: Lab #4  Exercise #4 
 *	Exercise Description: pressing '#'(PA2) then 'Y'(PA1) locks & unlocks the door, pressing PA7 locks the door
 *	
 *	I acknowledge all content contained herein, excluding template or example
 *	code, is my own original work.
 */

#include <avr/io.h>
#include <stdio.h>

enum States { START, LOCK, UNLOCK, INPUT_PWD } state;
unsigned char tmpA = 0x00, tmpB = 0x00, tmpC = 0x00;
unsigned char count = 0, input[2];
    
void Tick() {
    switch(state) { // Transitions
        case START:
            state = LOCK;
            break;
        case LOCK:
            if (tmpA & 0xFF) { // if any button is pressed
                state = INPUT_PWD;
            }
            break;
        case UNLOCK:
            if (tmpA & 0x80) { // if lock(PA7) is pressed
                state = LOCK;
            }
            else if (tmpA & 0xFF) { // if any button is pressed
                state = INPUT_PWD;
            }
            break;
        case INPUT_PWD:
            if (count < 2) { // loop until 2 buttons are pressed
                state = INPUT_PWD;
            }
            // PA2('#') --> PA1('Y') 
            else if (tmpB == 0x01) { // currently unlocked
                if (input[0] == 0x04 && input[1] == 0x02) { // correct sequence to lock
                    state = LOCK;
                }
                else { // fails sequence
                    state = UNLOCK;    
                }
            }
            else if (tmpB == 0x00) { // currently locked
                if (input[0] == 0x04 && input[1] == 0x02) { // correct sequence to unlock
                    state = UNLOCK;
                }
                else { // fails sequence
                    state = LOCK;
                }
            }
            break;
    }
    switch(state) { // State actions
		case START:
			
			break;
        case LOCK:
            tmpC = 0;
            tmpB = 0x00;
            PORTB = tmpB;
            for (count = 0; count < 2; count++) { // clear all input
                input[count] = 0;
            }
            count = 0; // reset counter here
            break;
        case UNLOCK:
            tmpC = 2;
            tmpB = 0x01;
            PORTB = tmpB;
            for (count = 0; count < 2; count++) { // clear all input
                input[count] = 0;
            }
            count = 0; // reset counter here
            break;
        case INPUT_PWD:
            //count = 0;
            tmpC = 1;
            input[count] = tmpA;
            count++;
            break;
    }
}

int main() {
    state = START;
    DDRA = 0x00; PORTA = 0xFF;
    DDRB = 0xFF; PORTB = 0x00;
    while(1) {
        tmpA = PINA & 0x87; // only receive input from pins A7, A2, A1, A0
        Tick();
    }
}

