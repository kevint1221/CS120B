/*	Partner(s) Name & E-mail: Jeff Trang (jtran094@ucr.edu), Kevin Tsai(ktsai017@ucr.edu), Xiangyu Chang(3750627@qq.com)
 *	Lab Section: 022
 *	Assignment: Lab #11  Exercise #1 
 *	Exercise Description: 
 *	
 *	I acknowledge all content contained herein, excluding template or example
 *	code, is my own original work.
 */
#include <avr/io.h>
#include <avr/interrupt.h>
#include <bit.h>
#include <keypad.h>
#include <timer.h>
#include "io.c"


//--------Find GCD function --------------------------------------------------
unsigned long int findGCD(unsigned long int a, unsigned long int b)
{
	unsigned long int c;
	while(1){
		c = a%b;
		if(c==0){return b;}
		a = b;
b = c;
	}
	return 0;
}
//--------End find GCD function ----------------------------------------------

//--------Task scheduler data structure---------------------------------------
// Struct for Tasks represent a running process in our simple real-time operating system.
typedef struct _task {
	/*Tasks should have members that include: state, period,
		a measurement of elapsed time, and a function pointer.*/
	signed char state; //Task's current state
	unsigned long int period; //Task period
	unsigned long int elapsedTime; //Time elapsed since last task tick
	int (*TickFct)(int); //Task tick function
} task;

//--------End Task scheduler data structure-----------------------------------

//--------Shared Variables----------------------------------------------------
unsigned char keyPressed = 0x00;
unsigned char* OutputString;

//--------End Shared Variables------------------------------------------------

//--------User defined FSMs---------------------------------------------------
//Enumeration of states.
enum SM_Keypad{start, _0, _1, _2 ,_3 ,_4, _5, _6, _7, _8, _9, A, B, C, D, hashtag, star, NONE};

// Monitors keypad. 
// write to shared value "outputstring"
int SMTick1(int state) 
{
	switch (state) {
		case start:
		keyPressed = GetKeypadKey();
		switch (keyPressed) {
			case '\0':state = NONE; break; 
			case '1': state = _1; break; 
			case '2': state = _2; break;
			case '3': state = _3; break;
			case '4': state = _4; break;
			case '5': state = _5; break;
			case '6': state = _6; break;
			case '7': state = _7; break;
			case '8': state = _8; break;
			case '9': state = _9; break;
			case 'A': state = A; break;
			case 'B': state = B; break;
			case 'C': state = C; break;
			case 'D': state = D; break;
			case '*': state = star; break;
			case '0': state = _0; break;
			case '#': state = hashtag; break;
			default: break;
		}break;
		case NONE: 
		case _1:
		case _2:
		case _3:
		case _4:
		case _5:
		case _6:
		case _7:
		case _8:
		case _9:
		case A:
		case B:
		case C:
		case D:
		case star:
		case _0:
		case hashtag: state = start; break;
		default:state = start; break;
	}
	switch (state) {
		case start:
		case NONE: break; 
		case _1: OutputString = "1"; break;
		case _2: OutputString = "2"; break;
		case _3: OutputString = "3"; break;
		case _4: OutputString = "4"; break;
		case _5: OutputString = "5"; break;
		case _6: OutputString = "6"; break;
		case _7: OutputString = "7"; break;
		case _8: OutputString = "8"; break;
		case _9: OutputString = "9"; break;
		case A: OutputString = "A"; break;
		case B: OutputString = "B"; break;
		case C: OutputString = "C"; break;
		case D: OutputString = "D"; break;
		case star: OutputString = "*"; break;
		case _0: OutputString = "0"; break;
		case hashtag: OutputString = "#"; break;
		default: break; 
	}
	return state;
}




//Enumeration of states.
enum SM_Display { display };
//Output on LCD
int SMTick2(int state) {
	//State machine transitions
	switch (state) {
	case display:	break;

	default:		state = display;
				break;
	}

	//State machine actions
	switch(state) {
	case display:	
		if (keyPressed != '\0')  //if nothing press at first, don't do anything
		{
			LCD_DisplayString(1, OutputString); // write shared outputs
			// to local variables
			LCD_Cursor(2);  //cursor won't block first letter
			
		}
		
		break;
	default:break;
	}
	return state;
}

// --------END User defined FSMs-----------------------------------------------

// Implement scheduler code from PES.
int main()
{
// Set Data Direction Registers
	DDRC = 0xF0; PORTC = 0x0F; //C for keypad 
	DDRA = 0xFF; PORTA = 0x00; //A, D for LCD
	DDRD = 0xFF; PORTD = 0x00;

// Period for the tasks
unsigned long int SMTick1_calc = 5;
unsigned long int SMTick2_calc = 10;

//Calculating GCD
unsigned long int tmpGCD = 1;
tmpGCD = findGCD(SMTick1_calc, SMTick2_calc);

//Greatest common divisor for all tasks or smallest time unit for tasks.
unsigned long int GCD = tmpGCD;

//Recalculate GCD periods for scheduler
unsigned long int SMTick1_period = SMTick1_calc/GCD;
unsigned long int SMTick2_period = SMTick2_calc/GCD;

//Declare an array of tasks 
static task task1, task2;
task *tasks[] = { &task1, &task2};
const unsigned short numTasks = sizeof(tasks)/sizeof(task*);

// Task 1
task1.state = -1;//Task initial state.
task1.period = SMTick1_period;//Task Period.
task1.elapsedTime = SMTick1_period;//Task current elapsed time.
task1.TickFct = &SMTick1;//Function pointer for the tick.

// Task 2
task2.state = -1;//Task initial state.
task2.period = SMTick2_period;//Task Period.
task2.elapsedTime = SMTick2_period;//Task current elapsed time.
task2.TickFct = &SMTick2;//Function pointer for the tick.



// Set the timer and turn it on
TimerSet(GCD);
TimerOn();
LCD_init();
LCD_ClearScreen();
unsigned short i; // Scheduler for-loop iterator
while(1) {
	// Scheduler code
	for ( i = 0; i < numTasks; i++ ) {
		// Task is ready to tick
		if ( tasks[i]->elapsedTime == tasks[i]->period ) {
			// Setting next state for task
			tasks[i]->state = tasks[i]->TickFct(tasks[i]->state);
			// Reset the elapsed time for next tick.
			tasks[i]->elapsedTime = 0;
		}
		tasks[i]->elapsedTime += 1;
	}
	while(!TimerFlag);
	TimerFlag = 0;
}

return 0;
}




