/*	Partner(s) Name & E-mail: Jeff Trang (jtran094@ucr.edu), Kevin Tsai(ktsai017@ucr.edu), Xiangyu Chang(3750627@qq.com)
 *	Lab Section: 022
 *	Assignment: Lab #11  Exercise #2 
 *	Exercise Description:
 *	
 *	I acknowledge all content contained herein, excluding template or example
 *	code, is my own original work.
 */

#include <avr/io.h>
//#include <bit.h>
#include "io.c"
#include <timer.h>
#include <string.h>

/*enum States{start, display}state;
void Tick()
{
	switch(state)
	{
		case start: if (!GetBit(PINA, 0)) state = display;break;
		case display: break;
	}
	switch(state)
	{
		case start: break;
		case display:
		LCD_DisplayString(17, string);
		string++;
		break;
	}
}*/

int main(void)
{
	//DDRA = 0x00; PORTA = 0xFF;
	DDRD = 0xFF; PORTD = 0x00;
	DDRC = 0xFF; PORTC = 0x00;
	TimerSet(500);
	TimerOn();
	LCD_init();
	unsigned char *string = "CS120B is Legend... wait for it DARY!";
	unsigned char len = strlen(string);
	unsigned char i = 1;
    while (1) 
    {
		LCD_DisplayString(17, string);
		if (i <= len) {string++;i++;}
		else {string -= len; i = 1;}
		while(!TimerFlag){};
		TimerFlag = 0;
    }
}
