#include <avr/io.h>
//#include <avr/interrupt.h>
#include <stdio.h>
#include "timer.h"
#include "io.c"
#include "bit.h"
#include "keypad.h"
#include "scheduler.h"





unsigned char x = 0x00; //for lcd read
unsigned char letter = 'C'; //for lcd display, set to C because if it is null, it fucked up on the lcd
unsigned char counter = 0; //for counting position of lcd
unsigned char trigger = 0;
//--------End Shared Variables------------------------------------------------

//--------User defined FSMs---------------------------------------------------
//Enumeration of states.


//Enumeration of states.
enum SM3_States { SM3_init, SM3_check, SM3_hold };

int SMTick3(int state) {
	//State machine transitions
	x = GetKeypadKey();
	switch (state) {
		case SM3_init:	
			
			if (x != '\0') //initially do nothing until  button press 
			{
				state = SM3_check;	
			}
			break;
		case SM3_check:
			if (x != '\0')  // if still holding button
			{
				state = SM3_hold;
			}
				
			break;
		case SM3_hold:
			if (x == '\0') //if not holding button anymore
			{
				state = SM3_check;
			}
			else
			
			break;
		default:		
			state = SM3_init;
			break;
	}

	//State machine actions
	switch(state) {
		case SM3_init:
			break;

		case SM3_check:
			if (x != '\0')
			{
				letter = x;
				trigger = 1;
				if (counter == 16)
				{
					counter = 0;
				}
				counter++;
			}
			break;
		case SM3_hold:
			break;
		
		default:
			break;
	}

	return state;
}


//Enumeration of states.
enum SM4_States { SM4_init, SM4_display, SM4_hold };

int SMTick4(int state) {
	// Local Variables

	//unsigned char output;

	//State machine transitions
	switch (state) {
		case SM4_init:	
			LCD_DisplayString(1, "Congratualation!");
			state = SM4_hold;
			break;
		case SM4_display:
			state = SM4_hold;
			break;
		case SM4_hold:
			if (trigger == 1)
			{
				
				state = SM4_display;
			}
			break;
		default:		
			state = SM4_init;
			break;
	}

	//State machine actions
	switch(state) {
		case SM4_init:
			break;
		case SM4_display:
			LCD_Cursor(counter);
			LCD_WriteData(letter);
			trigger = 0;
			break;
		case SM4_hold:
			break;
		default:
			break;
	}

	//PORTB = output;	// Write combined, shared output variables to PORTB

	return state;
}

// --------END User defined FSMs-----------------------------------------------

// Implement scheduler code from PES.
int main()
{
	// Set Data Direction Registers
	// Buttons PORTA[0-7], set AVR PORTA to pull down logic
	
	DDRC = 0xF0; PORTC = 0x0F; // PC7..4 outputs init 0s, PC3..0 inputs init 1s, keypad press

	DDRD = 0xFF; PORTD = 0x00; //for lcd
	DDRA = 0xFF; PORTA = 0x00; //for lcd
	
	// . . . etc

	// Period for the tasks
	unsigned long int SMTick3_calc = 2;
	unsigned long int SMTick4_calc = 1; //maybe 50

	//Calculating GCD
	unsigned long int tmpGCD = 1;
	tmpGCD = findGCD(SMTick3_calc, SMTick4_calc); //50

	//Greatest common divisor for all tasks or smallest time unit for tasks.
	unsigned long int GCD = tmpGCD;

	//Recalculate GCD periods for scheduler
	unsigned long int SMTick3_period = SMTick3_calc/GCD;// 4
	unsigned long int SMTick4_period = SMTick4_calc/GCD;// 1

	//Declare an array of tasks
	static task task3, task4;
	task *tasks[] = { &task3, &task4 };
	const unsigned short numTasks = sizeof(tasks)/sizeof(task*);

	// Task 3
	task3.state = -1;//Task initial state.
	task3.period = SMTick3_period;//Task Period.  //1
	task3.elapsedTime = SMTick3_period; // Task current elasped time. //1
	task3.TickFct = &SMTick3; // Function pointer for the tick.

	// Task 4
	task4.state = -1;//Task initial state.
	task4.period = SMTick4_period;//Task Period.   //2
	task4.elapsedTime = SMTick4_period; // Task current elasped time. //2
	task4.TickFct = &SMTick4; // Function pointer for the tick.

	// Set the timer and turn it on
	LCD_init();
	LCD_ClearScreen();
	
	TimerSet(GCD); // 50ms
	TimerOn();

	unsigned short i; // Scheduler for-loop iterator
	
	while(1) {
		// Scheduler code
		
		
		for ( i = 0; i < numTasks; i++ ) {
			// Task is ready to tick
			if ( tasks[i]->elapsedTime >= tasks[i]->period ) {
				// Setting next state for task
				tasks[i]->state = tasks[i]->TickFct(tasks[i]->state);
				// Reset the elapsed time for next tick.
				tasks[i]->elapsedTime = 0;
			}
			tasks[i]->elapsedTime += 1;
		}
		while(!TimerFlag);
		TimerFlag = 0;
	}

	// Error: Program should not exit!
	return 0;
}
