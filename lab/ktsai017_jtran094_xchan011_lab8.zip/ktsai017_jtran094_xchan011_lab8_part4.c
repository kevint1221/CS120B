/*	Partner(s) Name & E-mail: Jeff Trang (jtran094@ucr.edu), Kevin Tsai(ktsai017@ucr.edu), Xiangyu Chang(3750627@qq.com)
 *	Lab Section: 022
 *	Assignment: Lab #8  Exercise #4 
 *	Exercise Description: illuminate bank of eight LEDs based on light level
 *	
 *	I acknowledge all content contained herein, excluding template or example
 *	code, is my own original work.
 */

#include <avr/io.h>
#include <avr/interrupt.h>
#include "timer.h"

signed short x;
unsigned char tmpA = 0x00, tmpB = 0x00, tmpD = 0x00;
signed short high = 351; // �highest� value is between 350-380

enum States {START, SET, INC, DEC} state;

void ADC_init() {
    ADCSRA |= (1 << ADEN) | (1 << ADSC) | (1 << ADATE);
    // ADEN: setting this bit enables analog-to-digital conversion.
    // ADSC: setting this bit starts the first conversion.
    // ADATE: setting this bit enables auto-triggering. Since we are
    // in Free Running Mode, a new conversion will trigger whenever
    // the previous conversion completes.
}

void Tick() {
    switch(state) { // Transitions
        case START:
            state = SET;
            break;
        case SET:
            if (x - high > 79) {
                state = DEC;
                high = high + 79; // (1023 - 351) / 8 or (highest - lowest) / # of LEDs
            }
            else if (high - x > 79) {
                state = INC;
                high = high - 79;
            }
            else {
                state = SET;
            }
            break;
        case INC:
            if (x - high > 79) {
                state = DEC;
                high = high + 79;
            }
            else if (high - x > 79) {
                state = INC;
                high = high - 79;
            }
            
            break;
        case DEC:
            if (x - high > 79) {
                state = DEC;
                high = high + 79;
            }
            else if (high - x > 79) {
                state = INC;
                high = high - 79;
            }
            
            break;
    }
    switch(state) { // State actions
        case START:
            break;
        case SET:
            tmpB = 0xFF;
            PORTB = tmpB;
            break;
        case INC:
            tmpB = (tmpB << 1) + 0x01;
            PORTB = tmpB;
            break;
        case DEC:
            tmpB = tmpB >> 1;
            PORTB = tmpB;
            break;
    }
}

int main(void) {
    DDRA = 0x00; PORTA = 0xFF;
    DDRB = 0xFF; PORTB = 0x00;
    DDRD = 0xFF; PORTD = 0x00;   
    ADC_init();
    TimerSet(25);
    TimerOn();
    while (1) {
        x = ADC;
        Tick();
        while (!TimerFlag){}  // Wait for BL's period
        TimerFlag = 0;        // Lower flag
    }
}
