/*	Partner(s) Name & E-mail: Jeff Trang (jtran094@ucr.edu), Xiangyu Chang(3750627@qq.com)
 *	Lab Section: 022
 *	Assignment: Lab #2  Exercise #4 
 *	Exercise Description: turn on PC7 if all parking spaces are full
 *	I acknowledge all content contained herein, excluding template or example
 *	code, is my own original work.
 */
#include <avr/io.h>
int main(void) {
    	DDRA = 0x00; PORTA = 0xFF; //input, initial all pins to 1
	DDRB = 0x00; PORTB = 0xFF; //input, initial all pins to 1
	DDRC = 0x00; PORTC = 0xFF; //input, initial all pins to 1
	DDRD = 0xFF; PORTD = 0x00; //output, initial all pins to 0
	unsigned char tmpA = 0x00; //initial to 0;
	unsigned char tmpB = 0x00; //initial to 0;
	unsigned char tmpC = 0x00; //initial to 0;
	unsigned char tmpD = 0x00; //initial to 0;
	unsigned char tmpI = 0x00; //for avg
	int count=0; //total of a + b + c
	int avg; //the average weight of a + b + c
	int weight; //use for printf
	while(1)
	{
		tmpA = PINA;
		tmpB = PINB;
		tmpC = PINC;
		
		count = tmpA + tmpB + tmpC;
		
		//part3. find average of total weight
		
		avg = count / 15; // can divide any number, as long as the result is smaller than 6 bits(31)
		
		tmpD = avg;
		
		tmpD = tmpD << 2;  //shift left for two bit that reserved for tmpI
		
		weight = (tmpD >> 2) * 15; //present weight in decimal
		
		printf("the approximate weight is &d", weight);
	
	
		//part1. if a + b + c >= 140, D0 =1;
		if (count > 0x8C)  //  0x8C or 140 both work
		{
			tmpD =  tmpD + 0x01;
		}
		//part2. if the different is more than 80kg
		if ((tmpA - tmpC > 0x50) || ((tmpC - tmpA) > 0x50))
		{
			tmpD = tmpD + 0x02;
			
		} 
		PORTD = tmpD;

		
		 
		tmpD = 0x00; //reset
		
		

		

	}
	return 0;

}

