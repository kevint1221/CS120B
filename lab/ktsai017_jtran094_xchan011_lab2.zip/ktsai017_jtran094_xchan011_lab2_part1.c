/*	Partner(s) Name & E-mail: Jeff Trang (jtran094@ucr.edu), Xiangyu Chang(3750627@qq.com)
 *	Lab Section: 022
 *	Assignment: Lab #2  Exercise #1 
 *	Exercise Description: turn LED on when garage door is open at night
 *	
 *	I acknowledge all content contained herein, excluding template or example
 *	code, is my own original work.
 */

#include <avr/io.h>

int main(void) {
	DDRA = 0x00; PORTA = 0xFF; // Configure port A's 8 pins as inputs
	DDRB = 0xFF; PORTB = 0x00; // Configure port B's 8 pins as outputs, initialize to 0s
	unsigned char tmpA1 = 0x00, tmpA0 = 0x00; // Temporary variable to hold the value of A
    unsigned char tmpB = 0x00; // Temporary variable to hold the value of B
    
    while(1) {
		// 1) Read input
		tmpA1 = PINA & 0x02;
        tmpA0 = PINA & 0x01;
		// 2) Perform computation
		// if PA1 = 0 & PA0 = 1, set PB0 = 1, else PB0 = 0
        tmpB = (!tmpA1) && (tmpA0);	
		// 3) Write output
        PORTB = tmpB;	
	}
	return 0;
}

