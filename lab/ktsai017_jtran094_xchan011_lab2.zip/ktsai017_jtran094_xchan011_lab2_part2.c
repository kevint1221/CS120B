/*	Partner(s) Name & E-mail: Jeff Trang (jtran094@ucr.edu), Xiangyu Chang(3750627@qq.com)
 *	Lab Section: 022
 *	Assignment: Lab #2  Exercise #2 
 *	Exercise Description: output number of available parking spaces
 *	
 *	I acknowledge all content contained herein, excluding template or example
 *	code, is my own original work.
 */
#include <avr/io.h>

int main(void) {
    DDRA = 0x00; PORTA = 0xFF; // Configure port A's 8 pins as inputs
    DDRC = 0xFF; PORTC = 0x00; // Configure port C's 8 pins as outputs, initialize to 0s
    unsigned char tmpA0 = 0x00, tmpA1 = 0x00, tmpA2 = 0x00, tmpA3 = 0x00; // Temporary variable to hold the values of A
    unsigned char cntavail = 0x00; // holds the value of available parking spaces
    while(1) {
        // 1) Read input
        tmpA0 = PINA & 0x01; // PA# assigned to each bit
        tmpA1 = PINA & 0x02; 
        tmpA2 = PINA & 0x04; 
        tmpA3 = PINA & 0x08; 
        // 2) Perform computation
        if (tmpA0 == 0x00) { // if PA0 is empty, increase counter
            cntavail = cntavail + 0x01;
        }
        if (tmpA1 == 0x00){ // if PA1 is empty, increase counter
            cntavail = cntavail + 0x01;
        }
        if (tmpA2 == 0x00){ // if PA2 is 1, increase counter
            cntavail = cntavail + 0x01;
        }
        if (tmpA3 == 0x00){ // if PA3 is 1, increase counter
            cntavail = cntavail + 0x01;
        }
        // 3) Write output
        PORTC = cntavail;
        cntavail = 0x00; // reset counter
    }
    return 0;
}
